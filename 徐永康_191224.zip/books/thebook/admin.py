from django.contrib import admin
from thebook.models import User,Letter,Token
# Register your models here.
admin.site.register(User)
admin.site.register(Letter)
admin.site.register(Token)