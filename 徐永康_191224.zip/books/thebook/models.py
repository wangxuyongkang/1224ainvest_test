from django.db import models
# Create your models here.
from datetime import datetime

class User(models.Model):
    gender = (
        (1, '男'),
        (2, '女'),
    )
    # 手机号
    username = models.CharField(max_length=128)
    # 密码
    password = models.CharField(max_length=128)
    # 创建时间
    birthday = models.DateTimeField(default=datetime.now)
    # 性别默认为男
    gender = models.IntegerField(choices=gender, default=1)
    def __str__(self):
        return self.username
class Token(models.Model):
    # 跟用户关联
    user = models.OneToOneField(User)
    # 用户登陆成功后的token标识
    token = models.CharField(max_length=128)
    login_time = models.DateTimeField(default=datetime.now)

class Letter(models.Model):
    # 书名
    bookName = models.CharField(max_length=56)
    # 书籍介绍
    info = models.CharField(max_length=256)
    def __str__(self):
        return self.bookName





