from rest_framework import serializers
from thebook.models import User,Letter
class RegisterUserSerializer(serializers.ModelSerializer):
    password = serializers.CharField()

    class Meta:
        model = User
        fields = "__all__"

    def validated_password(self, value):
        # 定义验证方法
        import re
        from rest_framework.exceptions import ValidationError
        if re.match(R'[A-Z]', value):
            # 首字母大写
            if re.match(r'[a-z]', value) and re.search(r'[0-9]', value) and len(value) > 7:
                return value
            else:
                raise ValidationError('密码格式错误')
        else:
            raise ValidationError('密码首字母必须大写')

class ListallSerializer(serializers.ModelSerializer):

    class Meta:
        model = Letter
        fields = "__all__"
