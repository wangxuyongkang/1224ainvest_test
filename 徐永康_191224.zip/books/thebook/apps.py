from django.apps import AppConfig


class ThebookConfig(AppConfig):
    name = 'thebook'
