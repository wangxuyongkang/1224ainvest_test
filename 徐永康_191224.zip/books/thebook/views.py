from django.shortcuts import render
from rest_framework.views import APIView
from thebook.models import User, Token, Letter
from rest_framework.viewsets import GenericViewSet
from rest_framework.response import Response
from rest_framework import status
# Create your views here.
from rest_framework.mixins import CreateModelMixin, ListModelMixin
from .serializers import RegisterUserSerializer, ListallSerializer


class RegisterView(GenericViewSet, CreateModelMixin):
    serializer_class = RegisterUserSerializer

    def create(self, request, *args, **kwargs):
        ret = {
            'code': 1,
            'msg': '注册成功'
        }
        serializer = self.get_serializer(data=request.data)
        # is_valid验证
        if serializer.is_valid():
            self.perform_create(serializer)
            headers = self.get_success_headers(serializer.data)
            return Response(ret, status=status.HTTP_201_CREATED, headers=headers)
        else:
            print(serializer.errors)
            ret['code'] = 0
            ret['msg'] = '注册失败'
            return Response(ret)


##############生成token
import time
import hashlib


def get_token(username, password):
    # 根据用户名， 密码， time_str 生成token
    time_str = str(int(time.time() * 1000))
    md5_obj = hashlib.md5(time_str.encode('utf8'))
    md5_obj.update(username.encode('utf8'))
    md5_obj.update(password.encode('utf8'))
    return md5_obj.hexdigest()

class LoginView(APIView):
    def post(self, request, *args, **kwargs):
        ret = {
            'code': 1,
            'msg': '登陆成功',
        }
        try:
            # 获取post请求
            data = request.data
            # 用户名
            username = data.get('username')
            # 获取密码
            password = data.get('password')
            obj = User.objects.filter(username=username).first()
            if obj:
                # 存在
                if obj.password == password:
                    # 登陆成功 生成登陆标识 token
                    token = get_token(username, password)
                    Token.objects.update_or_create(user=obj, defaults={'token': token})
                    ret['token'] = token
                else:
                    # 密码错误
                    ret['msg'] = '账户或密码错误'
                    ret['code'] = 0
            else:
                ret['msg'] = '该用户不存在'
                ret['code'] = 0
        except Exception as err:
            print(err)
            ret['msg'] = '异常错误'
            ret['code'] = 0
        return Response(ret)

class ListView(ListModelMixin):
    queryset = Letter.objects.all()
    serializer_class = ListallSerializer
    def list(self, request, *args, **kwargs):
        ret = {
            'code': 1
        }
        queryset = self.filter_queryset(self.get_queryset())
        serializer = self.get_serializer(queryset, many=True)
        ret['data'] = serializer.data
        return Response(ret)

class CreatebookView(GenericViewSet, CreateModelMixin):
    serializer_class = ListallSerializer

    def create(self, request, *args, **kwargs):
        ret = {
            'msg': '添加成功'
        }
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            self.perform_create(serializer)
            headers = self.get_success_headers(serializer.data)
            return Response(ret, status=status.HTTP_201_CREATED, headers=headers)
        else:
            print(serializer.errors)
            ret['code'] = 0
            ret['msg'] = '添加成功'
            return Response(ret)


